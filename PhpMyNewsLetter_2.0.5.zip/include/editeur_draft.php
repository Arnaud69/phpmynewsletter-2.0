<!-- Start of header -->
<table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="header">
<tbody>
    <tr>
        <td>
            <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                <tbody>
                    <tr>
                        <td width="100%">
                            <table bgcolor="#f0f3f5" width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                <tbody>
                                    <tr>
                                        <td>
                                            <!-- logo -->
                                            <table width="140" align="left" border="0" cellpadding="0" cellspacing="0" class="devicewidth">
                                                <tbody>
                                                    <tr>
                                                        <td width="140" height="50" align="center">
                                                            <a target="_blank" href="#">
                                                                <img st-image="logo" src="https://placeholdit.imgix.net/~text?w=140&h=80" alt="" border="0" width="140" style="display:block; border:none; outline:none; text-decoration:none;"></a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <!-- end of logo -->
                                            <!-- start of menu -->
                                            <table width="250" height="50" border="0" align="right" valign="middle" cellpadding="0" cellspacing="0" class="devicewidth">
                                                <tbody>
                                                    <tr>
                                                        <td height="50" align="center" valign="middle" style="font-family: Helvetica, arial, sans-serif; font-size: 13px;color: #282828" st-content="menu">
                                                            <a href="#" style="color: #282828;text-decoration: none;">Home</a>
                                                            <a href="#" style="color: #282828;text-decoration: none;">Shop</a>
                                                            <a href="#" style="color: #282828;text-decoration: none;">Contact</a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <!-- end of menu -->
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</tbody>
</table>
<!-- End of Header -->
<!-- Start of seperator -->
<table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="separator">
<tbody>
    <tr>
        <td>
            <table width="600" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidth">
                <tbody>
                    <tr>
                        <td align="center" height="30" style="font-size:1px; line-height:1px;" st-content="separator">&nbsp;</td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</tbody>
</table>
<!-- End of seperator -->
<!-- Start of main-banner -->
<table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="banner">
<tbody>
    <tr>
        <td>
            <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                <tbody>
                    <tr>
                        <td width="100%">
                            <table width="600" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidth">
                                <tbody>
                                    <tr>
                                        <!-- start of image -->
                                        <td align="center">
                                            <a target="_blank" href="#"><img width="600" border="0" alt="" style="display:block; border:none; outline:none; text-decoration:none;" src="https://placeholdit.imgix.net/~text?w=600&h=300" class="banner" st-image="banner"></a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <!-- end of image -->
                        </td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</tbody>
</table>
<!-- End of main-banner -->
<!-- Start of seperator -->
<table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="separator">
<tbody>
    <tr>
        <td>
            <table width="600" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidth">
                <tbody>
                    <tr>
                        <td align="center" height="30" style="font-size:1px; line-height:1px;" st-content="separator">&nbsp;</td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</tbody>
</table>
<!-- End of seperator -->
<!-- Start of Left Image -->
<table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="left-image">
<tbody>
    <tr>
        <td>
            <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                <tbody>
                    <tr>
                        <td width="100%">
                            <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                <tbody>
                                    <tr>
                                        <td>
                                            <!-- Start of left column -->
                                            <table width="280" align="left" border="0" cellpadding="0" cellspacing="0" class="devicewidth">
                                                <tbody>
                                                    <!-- image -->
                                                    <tr>
                                                        <td width="280" height="140" align="center" class="devicewidth">
                                                            <img st-image="left-image" src="https://placeholdit.imgix.net/~text?w=280&h=140" alt="" border="0" width="280" style="display:block; border:none; outline:none; text-decoration:none;" class="col2img">
                                                        </td>
                                                    </tr>
                                                    <!-- /image -->
                                                </tbody>
                                            </table>
                                            <!-- end of left column -->
                                            <!-- spacing for mobile devices-->
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" class="mobilespacing">
                                                <tbody>
                                                    <tr>
                                                        <td width="100%" height="15" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <!-- end of for mobile devices-->
                                            <!-- start of right column -->
                                            <table width="280" align="right" border="0" cellpadding="0" cellspacing="0" class="devicewidth">
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <table width="280" align="center" border="0" cellpadding="0" cellspacing="0" class="devicewidth">
                                                                <tbody>
                                                                    <!-- title -->
                                                                    <tr>
                                                                        <td style="font-family: Helvetica, arial, sans-serif; font-size: 18px; color: #282828; text-align:left; line-height: 24px;" st-content="image-title">
                                                                            Your Heading Goes Here
                                                                        </td>
                                                                    </tr>
                                                                    <!-- end of title -->
                                                                    <!-- Spacing -->
                                                                    <tr>
                                                                        <td width="100%" height="15" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                                    </tr>
                                                                    <!-- /Spacing -->
                                                                    <!-- content -->
                                                                    <tr>
                                                                        <td style="font-family: Helvetica, arial, sans-serif; font-size: 14px; color: #889098; text-align:left; line-height: 24px;" st-content="image-content">
                                                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.
                                                                        </td>
                                                                    </tr>
                                                                    <!-- end of content -->
                                                                    <!-- Spacing -->
                                                                    <tr>
                                                                        <td width="100%" height="15" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                                    </tr>
                                                                    <!-- /Spacing -->
                                                                    <!-- read more -->
                                                                    <tr>
                                                                        <td>
                                                                            <table width="120" height="32" bgcolor="#f0f3f5" align="left" valign="middle" border="0" cellpadding="0" cellspacing="0" style="border-radius:3px;" st-button="learnmore">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td height="9" align="center" style="font-size:1px; line-height:1px;"> </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td height="14" align="center" valign="middle" style="font-family: Helvetica, Arial, sans-serif; font-size: 13px; font-weight:bold;color: #ffffff; text-align:center; line-height: 14px; ; -webkit-text-size-adjust:none;" st-title="fulltext-btn">
                                                                                            <a style="text-decoration: none;color: #282828; text-align:center;" href="#" st-content="learn-more-button">Learn More</a>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td height="9" align="center" style="font-size:1px; line-height:1px;"> </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                    <!-- end of read more -->
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <!-- end of right column -->
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</tbody>
</table>
<!-- End of Left Image -->
<!-- Start of seperator -->
<table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="separator">
<tbody>
    <tr>
        <td>
            <table width="600" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidth">
                <tbody>
                    <tr>
                        <td align="center" height="30" style="font-size:1px; line-height:1px;" st-content="separator">&nbsp;</td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</tbody>
</table>
<!-- End of seperator -->
<!-- start of Full text -->
<table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="full-text">
<tbody>
    <tr>
        <td>
            <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                <tbody>
                    <tr>
                        <td width="100%">
                            <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                <tbody>
                                    <!-- Spacing -->
                                    <tr>
                                        <td height="20" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                    </tr>
                                    <!-- Spacing -->
                                    <tr>
                                        <td>
                                            <table width="560" align="center" cellpadding="0" cellspacing="0" border="0" class="devicewidthinner">
                                                <tbody>
                                                    <!-- Title -->
                                                    <tr>
                                                        <td style="font-family: Helvetica, arial, sans-serif; font-size: 18px; color: #282828; text-align:center; line-height: 24px;" st-content="text-title">
                                                            Full Width Text block content
                                                        </td>
                                                    </tr>
                                                    <!-- End of Title -->
                                                    <!-- spacing -->
                                                    <tr>
                                                        <td width="100%" height="15" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                    </tr>
                                                    <!-- End of spacing -->
                                                    <!-- content -->
                                                    <tr>
                                                        <td style="font-family: Helvetica, arial, sans-serif; font-size: 14px; color: #889098; text-align:center; line-height: 24px;" st-content="text-content">
                                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod Tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                                        </td>
                                                    </tr>
                                                    <!-- End of content -->
                                                    <!-- Spacing -->
                                                    <tr>
                                                        <td width="100%" height="15" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                    </tr>
                                                    <!-- Spacing -->
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                    <!-- Spacing -->
                                    <tr>
                                        <td height="20" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                    </tr>
                                    <!-- Spacing -->
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</tbody>
</table>
<!-- End of Full Text -->
<!-- Start of seperator -->
<table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="separator">
<tbody>
    <tr>
        <td>
            <table width="600" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidth">
                <tbody>
                    <tr>
                        <td align="center" height="30" style="font-size:1px; line-height:1px;" st-content="separator">&nbsp;</td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</tbody>
</table>
<!-- End of seperator -->
<!-- Start of Right Image -->
<table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="right-image">
<tbody>
    <tr>
        <td>
            <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                <tbody>
                    <tr>
                        <td width="100%">
                            <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                <tbody>
                                    <tr>
                                        <td>
                                            <!-- Start of left column -->
                                            <table width="280" align="right" border="0" cellpadding="0" cellspacing="0" class="devicewidth">
                                                <tbody>
                                                    <!-- image -->
                                                    <tr>
                                                        <td width="280" height="140" align="center" class="devicewidth">
                                                            <img src="https://placeholdit.imgix.net/~text?w=280&h=140" alt="" border="0" width="280" st-image="right-image" style="display:block; border:none; outline:none; text-decoration:none;" class="col2img">
                                                        </td>
                                                    </tr>
                                                    <!-- /image -->
                                                </tbody>
                                            </table>
                                            <!-- end of left column -->
                                            <!-- spacing for mobile devices-->
                                            <table align="left" border="0" cellpadding="0" cellspacing="0" class="mobilespacing">
                                                <tbody>
                                                    <tr>
                                                        <td width="100%" height="15" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <!-- end of for mobile devices-->
                                            <!-- start of right column -->
                                            <table width="280" align="left" border="0" cellpadding="0" cellspacing="0" class="devicewidth">
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <table width="280" align="center" border="0" cellpadding="0" cellspacing="0" class="devicewidth">
                                                                <tbody>
                                                                    <!-- title -->
                                                                    <tr>
                                                                        <td style="font-family: Helvetica, arial, sans-serif; font-size: 18px; color: #282828; text-align:left; line-height: 24px;" st-content="right-heading">
                                                                            Your Heading Goes Here
                                                                        </td>
                                                                    </tr>
                                                                    <!-- end of title -->
                                                                    <!-- Spacing -->
                                                                    <tr>
                                                                        <td width="100%" height="15" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                                    </tr>
                                                                    <!-- /Spacing -->
                                                                    <!-- content -->
                                                                    <tr>
                                                                        <td style="font-family: Helvetica, arial, sans-serif; font-size: 14px; color: #889098; text-align:left; line-height: 24px;" st-content="right-text">
                                                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.
                                                                        </td>
                                                                    </tr>
                                                                    <!-- end of content -->
                                                                    <!-- Spacing -->
                                                                    <tr>
                                                                        <td width="100%" height="15" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                                    </tr>
                                                                    <!-- /Spacing -->
                                                                    <!-- read more -->
                                                                    <tr>
                                                                        <td>
                                                                            <table width="120" height="32" bgcolor="#f0f3f5" align="left" valign="middle" border="0" cellpadding="0" cellspacing="0" style="border-radius:3px;" st-button="learnmore">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td height="9" align="center" style="font-size:1px; line-height:1px;"> </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td height="14" align="center" valign="middle" style="font-family: Helvetica, Arial, sans-serif; font-size: 13px; font-weight:bold;color: #ffffff; text-align:center; line-height: 14px; ; -webkit-text-size-adjust:none;" st-title="fulltext-btn">
                                                                                            <a style="text-decoration: none;color: #282828; text-align:center;" href="#" st-content="right-button">Learn More</a>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td height="9" align="center" style="font-size:1px; line-height:1px;"> </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                    <!-- end of read more -->
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <!-- end of right column -->
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</tbody>
</table>
<!-- End of Right Image -->
<!-- Start of seperator -->
<table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="separator">
<tbody>
    <tr>
        <td>
            <table width="600" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidth">
                <tbody>
                    <tr>
                        <td align="center" height="30" style="font-size:1px; line-height:1px;" st-content="separator">&nbsp;</td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</tbody>
</table>
<!-- End of seperator -->
<!-- Start of footer -->
<table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="social">
<tbody>
    <tr>
        <td>
            <table bgcolor="#f0f3f5" width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                <tbody>
                    <tr>
                        <td width="100%">
                            <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                <tbody>
                                    <!-- Spacing -->
                                    <tr>
                                        <td height="10" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                    </tr>
                                    <!-- Spacing -->
                                    <tr>
                                        <td>
                                            <!-- Social icons -->
                                            <?php $PATH = ($row_config_globale['path'] == '/' ? $row_config_globale['path'] : '/' . $row_config_globale['path']); ?>
                                            <table width="300" align="center" border="0" cellpadding="0" cellspacing="0" class="devicewidth">
                                                <tbody>
                                                    <tr>
                                                        <td width="43" height="43" align="center">
                                                            <a target="_blank" href="#">
                                                                <img st-image="facebook" src="<?php echo $row_config_globale['base_url'] . $PATH ; ?>css/facebook.png" alt="" border="0" width="43" height="43" style="display:block; border:none; outline:none; text-decoration:none;" /></a>
                                                        </td>
                                                        <td align="left" width="20" style="font-size:1px; line-height:1px;"> </td>
                                                        <td width="43" height="43" align="center">
                                                            <a target="_blank" href="#">
                                                                <img st-image="twitter" src="<?php echo $row_config_globale['base_url'] . $PATH ; ?>css/twitter.png" alt="" border="0" width="43" height="43" style="display:block; border:none; outline:none; text-decoration:none;" /></a>
                                                        </td>
                                                        <td align="left" width="20" style="font-size:1px; line-height:1px;"> </td>
                                                        <td width="43" height="43" align="center">
                                                            <a target="_blank" href="#">
                                                                <img st-image="linkedin" src="<?php echo $row_config_globale['base_url'] . $PATH ; ?>css/linkedin.png" alt="" border="0" width="43" height="43" style="display:block; border:none; outline:none; text-decoration:none;" /></a>
                                                        </td>
                                                        <td align="left" width="20" style="font-size:1px; line-height:1px;"> </td>
                                                        <td width="43" height="43" align="center">
                                                            <a target="_blank" href="#">
                                                                <img st-image="youtube" src="<?php echo $row_config_globale['base_url'] . $PATH ; ?>css/youtube.png" alt="" border="0" width="43" height="43" style="display:block; border:none; outline:none; text-decoration:none;" /></a>
                                                        </td>
                                                        <td align="left" width="20" style="font-size:1px; line-height:1px;"> </td>
                                                        <td width="43" height="43" align="center">
                                                            <a target="_blank" href="#">
                                                                <img st-image="google+" src="<?php echo $row_config_globale['base_url'] . $PATH ; ?>css/googleplus.png" alt="" border="0" width="43" height="43" style="display:block; border:none; outline:none; text-decoration:none;" /></a>
                                                        </td>
                                                        <td align="left" width="20" style="font-size:1px; line-height:1px;"> </td>
                                                        <td width="43" height="43" align="center">
                                                            <a target="_blank" href="#">
                                                                <img st-image="pinterest" src="<?php echo $row_config_globale['base_url'] . $PATH ; ?>css/pinterest.png" alt="" border="0" width="43" height="43" style="display:block; border:none; outline:none; text-decoration:none;" /></a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <!-- end of Social icons -->
                                        </td>
                                    </tr>
                                    <!-- Spacing -->
                                    <tr>
                                        <td height="10" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                    </tr>
                                    <!-- Spacing -->
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</tbody>
</table>
<!-- End of footer -->