                         <div class="module">
                           <div class="preview">
                              <div class="mod_thumb" data-toggle="tooltip" data-placement="top" title="" data-original-title="social"><img src="../css/wysiwyg/social.jpg"></div>
                           </div>
                           <div class="view">
                              <table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="social">
                                 <tbody>
                                    <tr>
                                       <td>
                                          <table bgcolor="#f0f3f5" width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                             <tbody>
                                                <tr>
                                                   <td width="100%">
                                                      <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                                         <tbody>
                                                            <!-- Spacing -->
                                                            <tr>
                                                               <td height="10" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                               
                                                            </tr>
                                                            <!-- Spacing -->
                                                            <tr>
                                                               <td>
                                                                  <!-- Social icons -->
                                                                  <?php $PATH = ($row_config_globale['path'] == '/' ? $row_config_globale['path'] : '/' . $row_config_globale['path']); ?>
                                                                  <table width="300" align="center" border="0" cellpadding="0" cellspacing="0" class="devicewidth">
                                                                     <tbody>
                                                                        <tr>
                                                                           <td width="43" height="43" align="center">
                                                                              <a target="_blank" href="#">
                                                                              <img st-image="facebook" src="<?php echo $row_config_globale['base_url'] . $PATH ; ?>css/facebook.png" alt="" border="0" width="43" height="43" style="display:block; border:none; outline:none; text-decoration:none;" /></a>
                                                                           </td>
                                                                           <td align="left" width="20" style="font-size:1px; line-height:1px;"> </td>
                                                                           <td width="43" height="43" align="center">
                                                                              <a target="_blank" href="#">
                                                                              <img st-image="twitter" src="<?php echo $row_config_globale['base_url'] . $PATH ; ?>css/twitter.png" alt="" border="0" width="43" height="43" style="display:block; border:none; outline:none; text-decoration:none;" /></a>
                                                                           </td>
                                                                           <td align="left" width="20" style="font-size:1px; line-height:1px;"> </td>
                                                                           <td width="43" height="43" align="center">
                                                                              <a target="_blank" href="#">
                                                                              <img st-image="linkedin" src="<?php echo $row_config_globale['base_url'] . $PATH ; ?>css/linkedin.png" alt="" border="0" width="43" height="43" style="display:block; border:none; outline:none; text-decoration:none;" /></a>
                                                                           </td>
                                                                           <td align="left" width="20" style="font-size:1px; line-height:1px;"> </td>
                                                                           <td width="43" height="43" align="center">
                                                                              <a target="_blank" href="#">
                                                                              <img st-image="youtube" src="<?php echo $row_config_globale['base_url'] . $PATH ; ?>css/youtube.png" alt="" border="0" width="43" height="43" style="display:block; border:none; outline:none; text-decoration:none;" /></a>
                                                                           </td>
                                                                           <td align="left" width="20" style="font-size:1px; line-height:1px;"> </td>
                                                                           <td width="43" height="43" align="center">
                                                                              <a target="_blank" href="#">
                                                                              <img st-image="google+" src="<?php echo $row_config_globale['base_url'] . $PATH ; ?>css/googleplus.png" alt="" border="0" width="43" height="43" style="display:block; border:none; outline:none; text-decoration:none;" /></a>
                                                                           </td>
                                                                           <td align="left" width="20" style="font-size:1px; line-height:1px;"> </td>
                                                                           <td width="43" height="43" align="center">
                                                                              <a target="_blank" href="#">
                                                                              <img st-image="pinterest" src="<?php echo $row_config_globale['base_url'] . $PATH ; ?>css/pinterest.png" alt="" border="0" width="43" height="43" style="display:block; border:none; outline:none; text-decoration:none;" /></a>
                                                                           </td>
                                                                        </tr>
                                                                     </tbody>
                                                                  </table>
                                                                  <!-- end of Social icons -->
                                                               </td>
                                                               
                                                            </tr>
                                                            <!-- Spacing -->
                                                            <tr>
                                                               <td height="10" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                            </tr>
                                                            <!-- Spacing -->
                                                         </tbody>
                                                      </table>
                                                   </td>
                                                </tr>
                                             </tbody>
                                          </table>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </div>