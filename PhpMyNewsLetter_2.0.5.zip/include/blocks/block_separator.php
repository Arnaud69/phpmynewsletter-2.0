                            <div class="module">
                                <div class="preview">
                                    <div class="mod_thumb" data-toggle="tooltip" data-placement="top" title="" data-original-title="separator"><img src="../css/wysiwyg/separator.png"></div>
                                </div>
                                <div class="view">
                                    <table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="separator">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table width="600" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidth">
                                                        <tbody>
                                                            <tr>
                                                                <td align="center" height="30" style="font-size:1px; line-height:1px;" st-content="separator"> </td>

                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>