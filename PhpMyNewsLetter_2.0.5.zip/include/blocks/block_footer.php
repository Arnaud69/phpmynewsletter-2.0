                       <div class="module">
                           <div class="preview">
                              <div class="mod_thumb" data-toggle="tooltip" data-placement="top" title="" data-original-title="footer"><img src="../css/wysiwyg/footer.jpg"></div>
                           </div>
                           <div class="view">
                              <table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="footer">
                                 <tbody>
                                    <tr>
                                       <td>
                                          
                                          <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                             <tbody>
                                                <!-- Spacing -->
                                                <tr>
                                                   <td width="100%" height="20"></td>
                                                   
                                                </tr>
                                                <!-- Spacing -->
                                                <tr>
                                                   <td align="center" valign="middle" style="font-family: Helvetica, arial, sans-serif; font-size: 13px;color: #282828" st-content="preheader">
                                                      Don't want to receive email Updates? <span st-unsubscribe="" style="text-decoration: none; color: #f0f3f5">Unsubscribe here </span>
                                                   </td>
                                                   
                                                </tr>
                                                <!-- Spacing -->
                                                <tr>
                                                   <td width="100%" height="20"></td>
                                                   
                                                </tr>
                                                <!-- Spacing -->
                                             </tbody>
                                          </table>
                                       </td>
                                       
                                    </tr>
                                 </tbody>
                              </table>
                           </div>
                        </div>