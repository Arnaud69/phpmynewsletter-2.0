                            <div class="module">
                                <div class="preview">
                                    <div class="mod_thumb" data-toggle="tooltip" data-placement="auto" title="" data-original-title="header"><img src="../css/wysiwyg/header.jpg"></div>
                                </div>
                                <div class="view">
                                    <table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="header">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                                        <tbody>
                                                            <tr>
                                                                <td width="100%">
                                                                    <table bgcolor="#f0f3f5" width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <!-- logo -->
                                                                                    <table width="140" align="left" border="0" cellpadding="0" cellspacing="0" class="devicewidth">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td width="140" height="50" align="center">
                                                                                                    <a target="_blank" href="#">
                                                                                                        <img st-image="logo" src="https://placeholdit.imgix.net/~text?w=140&h=100" alt="" border="0" width="140" style="display:block; border:none; outline:none; text-decoration:none;" /></a>
                                                                                                </td>

                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                    <!-- end of logo -->
                                                                                    <!-- start of menu -->
                                                                                    <table width="250" height="50" border="0" align="right" valign="middle" cellpadding="0" cellspacing="0" class="devicewidth">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td height="50" align="center" valign="middle" style="font-family: Helvetica, arial, sans-serif; font-size: 13px;color: #282828" st-content="menu">
                                                                                                    <a href="#" style="color: #282828;text-decoration: none;">Home</a>

                                                                                                    <a href="#" style="color: #282828;text-decoration: none;">Shop</a>

                                                                                                    <a href="#" style="color: #282828;text-decoration: none;">Contact</a>

                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                    <!-- end of menu -->
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>