                            <div class="module">
                                <div class="preview">
                                    <div class="mod_thumb" data-toggle="tooltip" data-placement="top" title="" data-original-title="full-text"><img src="../css/wysiwyg/full-text.jpg"></div>
                                </div>
                                <div class="view">
                                    <table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="full-text">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                                        <tbody>
                                                            <tr>
                                                                <td width="100%">
                                                                    <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                                                        <tbody>
                                                                            <!-- Spacing -->
                                                                            <tr>
                                                                                <td height="20" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                                            </tr>
                                                                            <!-- Spacing -->
                                                                            <tr>
                                                                                <td>
                                                                                    <table width="560" align="center" cellpadding="0" cellspacing="0" border="0" class="devicewidthinner">
                                                                                        <tbody>
                                                                                            <!-- Title -->
                                                                                            <tr>
                                                                                                <td style="font-family: Helvetica, arial, sans-serif; font-size: 18px; color: #282828; text-align:center; line-height: 24px;" st-content="text-title">
                                                                                                    Full Width Text block content
                                                                                                </td>
                                                                                            </tr>
                                                                                            <!-- End of Title -->
                                                                                            <!-- spacing -->
                                                                                            <tr>
                                                                                                <td width="100%" height="15" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                                                            </tr>
                                                                                            <!-- End of spacing -->
                                                                                            <!-- content -->
                                                                                            <tr>
                                                                                                <td style="font-family: Helvetica, arial, sans-serif; font-size: 14px; color: #889098; text-align:center; line-height: 24px;" st-content="text-content">
                                                                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod Tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                                                                                </td>
                                                                                            </tr>
                                                                                            <!-- End of content -->
                                                                                            <!-- Spacing -->
                                                                                            <tr>
                                                                                                <td width="100%" height="15" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                                                            </tr>
                                                                                            <!-- Spacing -->
                                                                                        </tbody>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                            <!-- Spacing -->
                                                                            <tr>
                                                                                <td height="20" style="font-size:1px; line-height:1px; mso-line-height-rule: exactly;"> </td>
                                                                            </tr>
                                                                            <!-- Spacing -->
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>