                            <div class="module">
                                <div class="preview">
                                    <div class="mod_thumb" data-toggle="tooltip" data-placement="top" title="" data-original-title="banner"><img src="../css/wysiwyg/image.jpg"></div>
                                </div>
                                <div class="view">
                                    <table width="100%" bgcolor="#fcfcfc" cellpadding="0" cellspacing="0" border="0" st-sortable="banner">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                                        <tbody>
                                                            <tr>
                                                                <td width="100%">
                                                                    <table width="600" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidth">
                                                                        <tbody>
                                                                            <tr>
                                                                                <!-- start of image -->
                                                                                <td align="center">
                                                                                    <a target="_blank" href="#"><img width="600" border="0" alt="" style="display:block; border:none; outline:none; text-decoration:none;" src="https://placeholdit.imgix.net/~text?w=600&h=300" class="banner" st-image="banner" /></a>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <!-- end of image -->
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>