                            <div class="module">
                                <div class="preview">
                                    <div class="mod_thumb" data-toggle="tooltip" data-placement="auto" title="" data-original-title="preheader"><img src="../css/wysiwyg/preheader.png"></div>
                                </div>
                                <div class="view">
                                    <table width="100%" cellpadding="0" cellspacing="0" border="0" id="backgroundTable" st-sortable="preheader" bgcolor="#fcfcfc">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                                        <tbody>
                                                            <tr>
                                                                <td width="100%">
                                                                    <table width="600" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                                                                        <tbody>
                                                                            <!-- Spacing -->
                                                                            <tr>
                                                                                <td width="100%" height="20"></td>
                                                                            </tr>
                                                                            <!-- Spacing -->
                                                                            <tr>
                                                                                <td width="100%" align="center"  valign="middle" style="font-family: Helvetica, arial, sans-serif; font-size: 13px;color: #282828" st-content="preheader">
                                                                                    Can't see this Email? View it in your <span style="text-decoration: none; color: #224f6d" st-webversion="">Browser </span>
                                                                                </td>
                                                                            </tr>
                                                                            <!-- Spacing -->
                                                                            <tr>
                                                                                <td width="100%" height="20"></td>
                                                                            </tr>
                                                                            <!-- Spacing -->
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>

                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>