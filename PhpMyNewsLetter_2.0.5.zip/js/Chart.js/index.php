<?php
/**
* 2016 (c) PhpMyNewsLetter - Module pmnl - phpmynewsletter.com
*
* This file is a commercial module for Prestashop
* Do not edit or add to this file if you wish to upgrade PrestaShop or
* customize PrestaShop for your needs please refer to
* http://www.phpmynewsletter.com for more information.
*
* @author    phpmynewsletter.com <info@express-mailing.com>
* @copyright 2016 (c) PhpMyNewsLetter
* @license   http://opensource.org/licenses/GPL-3.0  GNU General Public License, version 3 (GPL-3.0)
*/
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: ".gmdate('D, d M Y H:i:s')." GMT");

header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

header("Location: ../../../../../");

exit;
